var canvas = document.getElementById("glcanvas");
var ctx = canvas.getContext("2d");
ctx.fillStyle = "#EE7070"; // red
ctx.fillRect(50, 50, 160, 80);
ctx.fillStyle = "#70CB55"; // green
ctx.fillRect(90, 80, 140, 70);
ctx.fillStyle = "#5C79AB"; // blue
ctx.fillRect(130, 110, 120, 60);
